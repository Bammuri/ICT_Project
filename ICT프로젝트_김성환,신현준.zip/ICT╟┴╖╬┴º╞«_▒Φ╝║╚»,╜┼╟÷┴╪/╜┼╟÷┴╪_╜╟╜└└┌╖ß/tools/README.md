## Document for tools
We provide a series of functions to read/write .wav file.
Since these are roughly implemented as MATLAB-like functions, I recommend to use your favorite library.
