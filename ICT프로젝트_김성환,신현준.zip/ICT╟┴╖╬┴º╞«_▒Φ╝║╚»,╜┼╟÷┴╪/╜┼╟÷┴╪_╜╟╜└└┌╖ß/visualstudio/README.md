## Document for Visual Studio

The project only supports a test using test.cpp.
In the project file, the option "-I $(SolutionDir)..\src -I $(SolutionDir)..\tools" was set to appropriately compile the program.
Please use makefile to use other examples. You can also make a project file to use them.
